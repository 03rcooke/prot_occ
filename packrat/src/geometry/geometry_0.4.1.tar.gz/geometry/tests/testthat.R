library(testthat)

test_check("geometry")
