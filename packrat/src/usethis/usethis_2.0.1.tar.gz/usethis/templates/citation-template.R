citHeader("To cite {{Package}} in publications use:")

citEntry(
  entry    = "Article",
  title    = ,
  author   = ,
  journal  = ,
  year     = ,
  volume   = ,
  number   = ,
  pages    = ,
  url      = ,
  textVersion = paste(

  )
)
