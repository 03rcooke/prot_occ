/* =========== fonctions adesub ============= */
void taballoc (double ***tab, int l1, int c1);
void vecintalloc (int **vec, int n);
void prodmatABC (double **a, double **b, double **c);
void freeintvec (int *vec);
void freetab (double **tab);
void aleapermutmat (double **a);
void prodmatAtAB (double **a, double **b);
void prodmatAAtB (double **a, double **b);
double alea (void);

