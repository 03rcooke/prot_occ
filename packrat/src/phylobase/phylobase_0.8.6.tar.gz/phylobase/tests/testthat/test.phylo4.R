#
# --- Test phylo4.R ---
#

# phylo4.R is mostly used to set generics, so no testing needed

# one non-exported method:
## test..genlab <- function() {
##     # use phylobase:::.genlab
## }

