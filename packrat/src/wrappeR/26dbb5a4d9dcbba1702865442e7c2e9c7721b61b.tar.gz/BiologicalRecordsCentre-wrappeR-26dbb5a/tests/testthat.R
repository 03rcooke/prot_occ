library(testthat)
library(wrappeR)

test_check("wrappeR")
